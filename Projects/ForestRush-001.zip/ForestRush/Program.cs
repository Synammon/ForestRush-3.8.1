﻿
using var game = new ForestRush.Game1();
game.Run();
